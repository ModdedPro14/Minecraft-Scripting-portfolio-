export const BLOCK_CONTAINERS = [
  "minecraft:chest",
  //"minecraft:barrel",
  "minecraft:trapped_chest",
  //"minecraft:dispenser",
  //"minecraft:dropper",
  //"minecraft:furnace",
  //"minecraft:blast_furnace",
  //"minecraft:lit_furnace",
  //"minecraft:lit_blast_furnace",
  //"minecraft:hopper",
  //"minecraft:shulker_box",
  //"minecraft:undyed_shulker_box",
];

export const CHECK_SIZE = { x: 7, y: 7, z: 7 };
