import { textToHex, hexToText } from './converters.js';
import { world } from '@minecraft/server';
import Server from './ServerBook.js';

const memory = {};
export class Database {
    constructor(table, identifier) {
        const id = identifier || 'db';
        if ((id + table).length > 16)
            throw Error('[Database] constructor(): Error - The table name is too long!');
        try {
            world.scoreboard.addObjective(id + table, '');
        }
        catch { }
        ;
        this.fullName = id + table;
        this.table = table;
        Object.assign(memory, { [this.fullName]: {} });
    }

    write(key, value) {
        Object.assign(memory[this.fullName], { [key]: [value, new Date().getTime()] });
        let keyL = world.scoreboard.getObjective(this.fullName).getScores().filter(p => p.participant.displayName.startsWith(key) && p.score != 0).length + 1, j = 1, data = textToHex(JSON.stringify(value));
        for (let l = 1; l < keyL; l++)
            Server.commandQueue(`scoreboard players reset "${key + l}" "${this.fullName}"`);
        for (const hex of data)
            Server.commandQueue(`scoreboard players set "${key + j}" "${this.fullName}" ${hex}`), j++;
        Server.commandQueue(`scoreboard players set "${key}" "${this.fullName}" 0`);
        return this;
    }

    read(key) {
        if (memory[this.fullName][key]?.[1])
            return memory[this.fullName][key][0];
        const scores = world.scoreboard.getObjective(this.fullName).getScores().filter(p => p.participant.displayName.startsWith(key) && p.score != 0).map(s => [parseInt(s.participant.displayName.replace(key, '')), s.score]).sort((a, b) => a[0] - b[0]).map(s => s[1]);
        if (!scores.length)
            return;
        const parts = JSON.parse(hexToText(scores));
        Object.assign(memory[this.fullName], { [key]: [parts, new Date().getTime()] });
        return parts;
    }
    
    has(key) {
        return Boolean(this.read(key));
    }

    delete(key) {
        delete memory[this.fullName][key];
        let length = world.scoreboard.getObjective(this.fullName).getScores().filter(p => p.participant.displayName.startsWith(key)).length + 1;
        for (let l = 1; l < length; l++)
            Server.commandQueue(`scoreboard players reset "${key + l}" "${this.fullName}"`);
        Server.commandQueue(`scoreboard players reset "${key}" "${this.fullName}"`);
        return this;
    }
}