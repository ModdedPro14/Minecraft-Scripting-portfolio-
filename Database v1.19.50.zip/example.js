//import Database From Database.js
import { Database } from "./Database.js";

//assign a database like this
const mydb = new Database("spawn")
//Set a value for a key
const value = 1
mydb.write('spawn', value)
//delete a value from a key
mydb.delete('spawn')
//get a value from a key
mydb.read('spawn')
//check if database has a key
mydb.has('spawn')
