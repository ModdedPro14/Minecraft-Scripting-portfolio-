export const textToHex = (text) => text.split('').map(char => char.charCodeAt()), 

hexToText = (hex) => hex.map(char => String.fromCharCode(char)).join('');